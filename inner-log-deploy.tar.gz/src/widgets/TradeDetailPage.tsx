// src/widgets/TradeDetailPage.tsx
// このファイルは TradeDiaryPage に統合されました
// TradeListPage から TradeDiaryPage へのリンクが設定されています

export default function TradeDetailPage() {
  return null;
}
